<?php
namespace ThemeXpert\Onepager\Adapters;

class Joomla {

}
