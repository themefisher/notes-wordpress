<?php namespace ThemeXpert\Providers\Contracts;

interface ToolbarInterface {
	public function addMenu( $id, $href, $title );
}
