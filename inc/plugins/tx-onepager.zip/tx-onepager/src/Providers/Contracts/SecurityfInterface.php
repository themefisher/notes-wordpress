<?php namespace ThemeXpert\Providers\Contracts;

interface SecurityInterface {

}
