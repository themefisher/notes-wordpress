#<?php echo $id; ?>{
	background : <?php echo $styles['bg_color'];?>;
}
#<?php echo $id; ?> .section-title{
	font-size : <?php echo $settings['title_size']?>px;
	color : <?php echo $styles['title_color'];?>;
}
#<?php echo $id; ?> .icon{
	background : <?php echo $styles['icon_bg'];?>;
	color : #fff;
	border-radius: 50%;
}
