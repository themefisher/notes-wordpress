#<?php echo $id ?>{
	background-color : <?php echo $styles['bg_color']?>;
}
#<?php echo $id?> .title a{
	color : <?php echo $styles['title_color']?>;
}

#<?php echo $id?> .title a:hover{
	color : <?php echo $styles['link_color']?>;
}

#<?php echo $id?> .desc{
	color : <?php echo $styles['text_color']?>;
}

#<?php echo $id?> .desc a{
	color : <?php echo $styles['link_color']?>;
}