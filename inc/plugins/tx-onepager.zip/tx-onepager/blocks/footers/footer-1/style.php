#<?php echo $id ?>{
	background : <?php echo $styles['bg_color']?>;
	color : <?php echo $styles['text_color']?>;
}
#<?php echo $id ?> a{
	color : <?php echo $styles['text_color']?>;	
}