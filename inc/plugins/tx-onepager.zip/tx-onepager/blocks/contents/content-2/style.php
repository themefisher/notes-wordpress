#<?php echo $id?>{
	background-color : <?php echo $styles['bg_color']?>;
	color : <?php echo $styles['text_color']?>;
}

#<?php echo $id?> .section-title{
	font-size : <?php echo $settings['title_size']?>px;
	color : <?php echo $styles['title_color']?>;
}

#<?php echo $id?> .op-media{
	color : <?php echo $styles['icon_color']?>;
}
