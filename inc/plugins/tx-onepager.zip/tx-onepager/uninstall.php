<?php
/**
 * Created by IntelliJ IDEA.
 * User: na
 * Date: 7/9/15
 * Time: 4:45 AM
 */

if( !defined( 'ABSPATH' ) && !defined( 'WP_UNINSTALL_PLUGIN' ) )
    exit();

//do cleanup